from .title_bar import TitleBar
from .resize_handle import ResizeHandle
from .navigation_bar import NavigationBar
from .web_view import CustomWebView
from .content_widget import ContentWidget