Smart AI Sidebar - Linux Installation
=====================================

How to install:
1. Open Terminal in this folder.
2. Run the following command:
   ./install.sh

3. The app will be installed to ~/.local/share/SmartAI
   and a shortcut will be added to your Application Menu.

Enjoy!
